#!/bin/sh
./t-rex -a octopus -o stratum+tcp://cfx-eu1.nanopool.org:17777 -u 0x100851451584c1e808fde4a2d077dd81129b2555.rig0/some@email.org -p x
